# 🔐 Sauvegarde & Restauration RAID – production3

Ce serveur utilise un système RAID logiciel (mdadm) avec les volumes suivants :

- `/dev/md0` → /boot
- `/dev/md1` → /
- `/dev/md2` → /var/www (exclu des sauvegardes RAID système)
- `/dev/md3` → /home (exclu des sauvegardes RAID système)

---

## ✅ Sauvegarde : `make_raid_backup.sh`

### 📦 Ce script :
- Sauvegarde uniquement les volumes critiques du système :
  - `/dev/md0` (boot)
  - `/dev/md1` (root)
- Format : `mdX_backup_YYYY-MM-DD.img.gz`
- Destination : `/mnt/backup`

---

## 🔁 Restauration : `restore_raid_backup.sh`

### 🧩 Ce script :
- Demande le nom d’un fichier `.img.gz` à restaurer
- Demande le volume RAID cible (`/dev/mdX`)
- Décompresse et écrit les données via `dd`

---

## 🧪 Vérification : `verify_raid_backups.sh`

- Vérifie que les fichiers `.img.gz` pour `/dev/md0` et `/dev/md1` existent
- Affiche la taille et la date de chaque archive
- Alerte si une archive est manquante

---

## 📡 Transfert vers serveur distant : `send_backup_to_remote.sh`

- Utilise `rsync` pour envoyer les archives vers `/home/elie/Backup/...` sur `62.210.124.12`
- Accepte un mode `--dry-run` pour simuler

